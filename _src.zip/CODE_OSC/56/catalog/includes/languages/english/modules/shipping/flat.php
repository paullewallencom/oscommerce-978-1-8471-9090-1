<?php
/*
  $Id: flat.php,v 1.5 2002/11/19 01:48:08 dgw_ Exp $

  Modified by Monika Math�
  http://www.monikamathe.com

  Module Copyright (c) 2006 Monika Math�

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_FLAT_TEXT_TITLE', 'Spot Delivery');
define('MODULE_SHIPPING_FLAT_TEXT_DESCRIPTION', 'Spot Delivery, tied to COD payment only');
define('MODULE_SHIPPING_FLAT_TEXT_WAY', 'COD');
?>
