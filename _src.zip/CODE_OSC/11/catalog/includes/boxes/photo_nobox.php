<?php
/*
  $Id: photo_nobox.php,v 1.00 2006/06/12 00:00:00 mm Exp $

  Module written by Monika Math�
  http://www.monikamathe.com

  Module Copyright (c) 2006 Monika Math�

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/
?>
<!-- photo_nobox //-->
          <tr>
            <td>
<?php
	echo '<a href="' . tep_href_link(FILENAME_CONTACT_US) . '">' . tep_image(DIR_WS_IMAGES . 'monika.jpg', 'Contact Monika Math�', BOX_WIDTH, '') . '</a>';
?>
            </td>
          </tr>
<!-- photo_nobox_eof //-->
