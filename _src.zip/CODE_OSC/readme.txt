Hi and thanks for buying my book,

Here is the code I promised you.
Each recipe has its own folder, which contains all the files that went into the cooking. 
Read through it carefully instead of just copying it in, ok? You will learn a lot by just reading code, promised.
For already customized shops, I highly recommend a file comparer like the one listed below.

Now dig in knee deep and have fun!

If you like my book, you can leave a nice message here: http://www.monikamathe.com/contact_us.php 

--------------------

:-)
Monika

addicted to writing code ... can't get enough of databases either, LOL!

my toolbox: Textpad - Compare and Merge - phpMyAdmin - WS_FTP - Photoshop
