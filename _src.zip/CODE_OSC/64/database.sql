ALTER TABLE products
ADD products_expires_date datetime,
ADD products_date_status_change datetime;
