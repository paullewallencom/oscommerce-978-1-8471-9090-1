<?php
/*
  $Id: levels.php,v 1.00 2006/07/09 00:00:00 mm Exp $

  Module written by Monika Math�
  http://www.monikamathe.com

  Module Copyright (c) 2006 Monika Math�

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_LEVELS_TEXT_TITLE', 'Per Item');
define('MODULE_SHIPPING_LEVELS_TEXT_DESCRIPTION', 'Per Item Module with 2 levels of fees');
define('MODULE_SHIPPING_LEVELS_TEXT_WAY', 'Best Way');
?>
