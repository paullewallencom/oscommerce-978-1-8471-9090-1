<?php
/*
  $Id: flat.php,v 1.5 2002/11/19 01:48:08 dgw_ Exp $
  cloned as
  $Id: flat1.php,v 1.00 2006/07/08 00:00:00 mm Exp $

  Modified by Monika Math�
  http://www.monikamathe.com

  Module Copyright (c) 2006 Monika Math�
  
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_FLAT1_TEXT_TITLE', 'Flat Fee');
define('MODULE_SHIPPING_FLAT1_TEXT_DESCRIPTION', 'Flat Fee for single item order in a selected category');
define('MODULE_SHIPPING_FLAT1_TEXT_WAY', 'Best Way');
?>
