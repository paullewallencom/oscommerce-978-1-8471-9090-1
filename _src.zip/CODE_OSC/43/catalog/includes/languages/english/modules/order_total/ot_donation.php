<?php
/*
  $Id: ot_donation.php,v 1.00 2006/07/05 00:00:00 mm Exp $

  Module written by Monika Math�
  http://www.monikamathe.com

  Module Copyright (c) 2006 Monika Math�

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_DONATION_TITLE', 'Donation');
  define('MODULE_ORDER_TOTAL_DONATION_DESCRIPTION', 'Donation');

  define('TEXT_ENTER_DONATION_HEADER', 'Contribute an extra donation');
  define('TEXT_ENTER_DONATION_INFO', 'Enter an amount here to give an extra gift');
  define('TEXT_ENTER_YOUR_DONATION', 'Your donation amount');

  define('TEXT_DONATION_ERROR', 'Please enter a correct value for your donation.');
?>
