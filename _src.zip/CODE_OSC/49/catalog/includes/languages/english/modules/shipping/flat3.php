<?php
/*
  $Id: flat.php,v 1.5 2002/11/19 01:48:08 dgw_ Exp $
  cloned as
  $Id: flat3.php,v 1.00 2006/07/08 00:00:00 mm Exp $

  Modified by Monika Math�
  http://www.monikamathe.com

  Module Copyright (c) 2006 Monika Math�
  
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_FLAT3_TEXT_TITLE', 'Flat Rate');
define('MODULE_SHIPPING_FLAT3_TEXT_DESCRIPTION', 'Flat Rate for the Rest of the World');
define('MODULE_SHIPPING_FLAT3_TEXT_WAY', 'Best Way');
?>
