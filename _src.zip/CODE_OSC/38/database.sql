UPDATE PRODUCTS set manufacturers_id = '5' where manufacturers_id = '0' or manufacturers_id is NULL;
