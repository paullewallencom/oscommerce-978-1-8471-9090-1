<?php
/*
  $Id: flexible.php,v 1.00 2006/07/08 00:00:00 mm Exp $

  Module written by Monika Math�
  http://www.monikamathe.com

  Module Copyright (c) 2006 Monika Math�

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_FLEXIBLE_TEXT_TITLE', 'Table Rate');
define('MODULE_SHIPPING_FLEXIBLE_TEXT_DESCRIPTION', 'Flexible Table Rate, allowing the use of percentage alone or combined with a base price');
define('MODULE_SHIPPING_FLEXIBLE_TEXT_WAY', 'Best Way');
?>
